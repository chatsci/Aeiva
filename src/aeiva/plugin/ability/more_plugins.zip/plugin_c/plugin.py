# plugin_c.py

from aeiva.plugin.plug import Plugin

class PluginC(Plugin):
    """
    Example Plugin C.
    """

    def activate(self) -> None:
        print("PluginC activated.")

    def deactivate(self) -> None:
        print("PluginC deactivated.")

    def run(self) -> None:
        print("PluginC is running.")